const booksData = [
    {
        keys : 1,
        srclink  : "https://www.britannica.com/topic/Iron-Man-comic-book-character",
        bookname : "IRON MAN(TONY STARK)",
        imglink  : "https://www.ubackground.com/_ph/86/956398707.jpg"

    },
    {
        keys : 2,
        srclink  : "https://marvel.fandom.com/wiki/Thor_Odinson_(Earth-616)",
        bookname : "Thor(OdinSon)",
        imglink  : "https://www.ubackground.com/_ph/22/901450491.jpg"

    },
    {
        keys : 3,
        srclink  : "https://www.britannica.com/topic/Loki",
        bookname : "LOKI(ASGARD)",
        imglink  : "https://www.ubackground.com/_ph/22/942657439.jpg"

    },
    {
        keys : 4,
        srclink  : "https://en.wikipedia.org/wiki/Captain_America",
        bookname : "Steve Rogers(Captain America)",
        imglink  : "https://www.ubackground.com/_ph/22/373790406.jpg"

    },
    {
        keys : 5,
        srclink  : "https://www.marvel.com/characters/hulk-bruce-banner",
        bookname : "HULK(Dr Banner)",
        imglink  : "https://www.ubackground.com/_ph/11/955630992.jpg"

    },
    {
        keys : 6,
        srclink  : "https://www.marvel.com/characters/doctor-strange-stephen-strange",
        bookname : "Doctor Strange",
        imglink  : "https://www.ubackground.com/_ph/86/441587699.jpg"
    },
]

export default booksData;