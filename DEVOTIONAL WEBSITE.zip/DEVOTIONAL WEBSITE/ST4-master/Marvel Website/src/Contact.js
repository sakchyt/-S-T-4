import React from 'react'

const Contact = () => {
  return (
    <div className = 'aboutspace'>
          <h1>PHONE NO - 9877179188 ----------------</h1>
          <br/>
          <h1>EMAIL ID - SAKSHAM2000.SHARMA@gmail.com ---------------</h1>
        
    </div>
  )
}

export default Contact